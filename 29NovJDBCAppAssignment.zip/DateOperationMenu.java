package DateOperation;
import java.io.IOException;
import java.sql.*;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.text.ParseException;
import java.text.SimpleDateFormat;
public class DateOperationMenu {
	public static void enterReturn() throws IOException {
		System.out.println("\nPress Enter return back to the menu...");
		System.in.read();
	}
	public static void main(String[] args) throws SQLException, ParseException, IOException {
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet resultSet = null;
		String sqlSelectQuery = "select * from employee where name = ?";
		String sqlInsertQuery = "insert into employee values (?,?,?,?,?,?)";
		try(Scanner sc = new Scanner(System.in)){
			while(true) {
				System.out.println("=========== Date DB Operation Menu ===========\n"
						+ "Enter number as per below list:- \n"
						+ "1 Retrieve\n"
						+ "2 Insert\n"
						+ "0 Exit\n"
						+ "==============================================\n");
				int number = sc.nextInt();
				switch(number) {
					case 1: 
						System.out.print("Enter Name:- ");
						String name = sc.next();
						connection = JdbcUtil.getJdbcConnection();
						if(connection != null) {
							pstmt = connection.prepareStatement(sqlSelectQuery);
							if(pstmt != null) {
								pstmt.setString(1, name);
								resultSet = pstmt.executeQuery();
								if(resultSet != null) {
									if(resultSet.next()) {
										String userName = resultSet.getNString(1);
										String userAddress = resultSet.getNString(2);
										String userGender = resultSet.getString(3);
										java.sql.Date userDob = resultSet.getDate(4);
										String date1 = new SimpleDateFormat("dd-MM-yyyy").format(userDob);
										java.sql.Date userDoj = resultSet.getDate(5);
										String date2 = new SimpleDateFormat("MM-dd-yyyy").format(userDoj);
										java.sql.Date userDom = resultSet.getDate(6);
										String date3 = new SimpleDateFormat("yyyy-MM-dd").format(userDom);
										System.out.println("Below are the employee details:- ");
										System.out.print("Name:- "+userName 
												+"\nAddress:- "+userAddress
												+"\nGender:- "+userGender
												+"\nDOB:- "+date1
												+"\nDOJ:- "+date2
												+"\nDOM:- "+date3+"\n");
									}else {
										System.out.println("Not able to retrieve the data for the given name:- "+name);
									}
								}
							}
						}
						enterReturn();
						break;
					case 2: 
						System.out.print("Enter Name:- ");
						String name1 = sc.next();
						System.out.print("Enter Address:- ");
						String address = sc.next();
						System.out.print("Enter gender in format(M/F/O):- ");
						String gender = sc.next();
						System.out.print("Enter Date of Birth in format(dd-MM-yyyy):-");
						String dob = sc.next();
						long time1 = new SimpleDateFormat("dd-MM-yyyy").parse(dob).getTime();
						java.sql.Date sqlDob = new java.sql.Date(time1);
						System.out.print("Enter Date of Joining in format(MM-dd-yyyy):-");
						String doj = sc.next();
						long time2 = new SimpleDateFormat("MM-dd-yyyy").parse(doj).getTime();
						java.sql.Date sqlDoj = new java.sql.Date(time2);
						System.out.print("Enter Date of Marriage in format(yyyy-MM-dd):-");
						String dom = sc.next();
						long time3 = new SimpleDateFormat("yyyy-MM-dd").parse(dom).getTime();
						java.sql.Date sqlDom = new java.sql.Date(time3);
						connection = JdbcUtil.getJdbcConnection();
						if(connection != null) {
							pstmt = connection.prepareStatement(sqlInsertQuery);
							if(pstmt != null) {
								pstmt.setString(1, name1);
								pstmt.setString(2, address);
								pstmt.setString(3, gender);
								pstmt.setDate(4, sqlDob);
								pstmt.setDate(5, sqlDoj);
								pstmt.setDate(6, sqlDom);
								int arows = pstmt.executeUpdate();
								if(arows>0)
									System.out.println("No. of rows affected:- "+arows);
								else
									System.out.println("Record not able to insert.");
							}
						}
						enterReturn();
						break;
					case 0:
						System.out.println("Bye!! See you again.");
						System.exit(0);
					default:System.out.println("Please enter number between 1 to 2 only...");
				}
			}
		}catch(InputMismatchException e) {
			System.out.println("Please enter number only.");
		}catch(ParseException e) {
			System.out.println("\nSorry... Please enter the data in the asked format only.");
		}finally {
			JdbcUtil.closeConnection(resultSet, pstmt, connection);
		}
	}
}