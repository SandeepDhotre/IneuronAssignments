package PreparedStatement;
import java.io.IOException;
import java.sql.*;
import java.util.InputMismatchException;
import java.util.Scanner;

public class CRUDPSMenu {
	
	public static void enterReturn() throws IOException {
		System.out.println("\nPress Enter return back to the menu...");
		System.in.read();
	}

	public static void main(String[] args) throws SQLException {
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet resultSet = null;
		
		String url = "jdbc:mysql://localhost:3306/enterprisejavabatch";
		String username = "root";
		String password = "Root@123";
		
		String sqlSelectQuery="select sid,sname,sage,saddr from student where sid=?";
		String sqlInsertQuery ="insert into student values (?,?,?,?)";
		String sqlUpdateQuery = "update student set sage=? where sid=?";
		String sqlDeleteQuery ="delete from student where sid=?";
		
		try (Scanner sc = new Scanner(System.in)) {
			while(true) {
				System.out.println("========= PrePared Statement DB Menu =========\n"
						+ "Enter number as per below list:- \n"
						+ "1 Select\n"
						+ "2 Insert\n"
						+ "3 Update\n"
						+ "4 Delete\n"
						+ "0 Exit\n"
						+ "==============================================\n");
				int number = sc.nextInt();
				
				switch(number) {
					case 1: 
						System.out.print("Enter Sid:- ");
						int sid = sc.nextInt();
						connection = DriverManager.getConnection(url,username,password);
						if(connection != null) {
							pstmt = connection.prepareStatement(sqlSelectQuery);
							if(pstmt != null) {
								pstmt.setInt(1, sid);
								resultSet = pstmt.executeQuery();
								if(resultSet != null) {
									if(resultSet.next()) {
										System.out.println("SID\tSNAME\tSAGE\tSADDR");
										System.out.println(resultSet.getInt(1)+"\t"+resultSet.getString(2)+"\t"+resultSet.getInt(3)+"\t"+resultSet.getString(4));
									}else
										System.out.println("Record is not available to retrieve for the given id:- "+sid);
									resultSet.close();
								}
								pstmt.close();
							}
							connection.close();
						}
						enterReturn();
						break;
					case 2:
						System.out.print("Enter Sid to insert the record into the student table:- ");
						int sidIn = sc.nextInt();
						System.out.print("Enter Sname to insert the record into the student table:- ");
						String sname = sc.next();
						System.out.print("Enter Sage to insert the record into the student table:- ");
						int sage = sc.nextInt();
						System.out.print("Enter Saddr to insert the record into the student table:- ");
						String saddr = sc.next();
						connection = DriverManager.getConnection(url,username,password);
						if(connection != null) {
							pstmt = connection.prepareStatement(sqlInsertQuery);
							if(pstmt != null) {
								pstmt.setInt(1, sidIn);
								pstmt.setString(2, sname);
								pstmt.setInt(3, sage);
								pstmt.setString(4, saddr);
								int arows=pstmt.executeUpdate();
								if(arows>0)
									System.out.println("Number of rows affected:- "+arows);
								else
									System.out.println("Record not able to insert.");
								pstmt.close();
							}
							connection.close();
						}
						enterReturn();
						break;
					case 3:
						System.out.print("Enter Sid to update the record into the student table:- ");
						int sidup = sc.nextInt();
						System.out.print("Enter Sage to update the record into the student table:- ");
						int sage1 = sc.nextInt();
						connection = DriverManager.getConnection(url, username, password);
						if(connection != null) {
							pstmt = connection.prepareStatement(sqlUpdateQuery);
							if(pstmt != null) {
								pstmt.setInt(1, sage1);
								pstmt.setInt(2, sidup);
								int arows = pstmt.executeUpdate();
								if(arows>0) {
									System.out.println("Number of rows affected:- "+arows);
								}else
									System.out.println("Record is not available to update for the given sid:- "+sidup);
								pstmt.close();
							}
							connection.close();
						}
						enterReturn();
						break;
					case 4:
						System.out.print("Enter Sid to delete from the student table:- ");
						int sidDel = sc.nextInt();
						connection = DriverManager.getConnection(url,username,password);
						if(connection != null) {
							pstmt = connection.prepareStatement(sqlDeleteQuery);
							if(pstmt != null) {
								pstmt.setInt(1, sidDel);
								int arows = pstmt.executeUpdate();
								if(arows>0)
									System.out.println("Number of rows affected:- "+arows);
								else
									System.out.println("Sorry, Sid "+sidDel +" not present to delete in the student table.");
								pstmt.close();
							}
							connection.close();
						}
						enterReturn();
						break;
					case 0:
						System.out.println("Bye!! See you again.");
						System.exit(0);
					default:System.out.println("Please enter number between 1 to 4 only...");
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch(InputMismatchException e) {
			System.out.println("Please enter number only.");
		}
	}
}