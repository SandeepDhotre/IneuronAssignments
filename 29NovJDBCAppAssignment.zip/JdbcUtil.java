package DateOperation;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
public class JdbcUtil {
	public static Connection getJdbcConnection() throws SQLException {
		Connection connection = null;
		String url="jdbc:mysql://localhost:3306/enterprisejavabatch";
		String username="root";
		String password="Root@123";
		connection = DriverManager.getConnection(url, username, password);
		if(connection != null) {
			return connection;
		}
		return connection;
	}
	public static void closeConnection(ResultSet resultSet, PreparedStatement pstmt, Connection connection) throws SQLException {
		if(resultSet != null)
			resultSet.close();
		if(pstmt != null)
			pstmt.close();
		if(connection != null)
			connection.close();
	}
}