import java.io.IOException;
import java.sql.*;
import java.util.InputMismatchException;
import java.util.Scanner;
public class InsertSelectUpdateDeleteMenuApp {
	static Connection connection;
	public static void enterReturn() throws IOException {
		System.out.println("\nPress Enter return back to the menu...");
		System.in.read();
	}
	public static void main(String[] args) throws SQLException, IOException {
		
		String url="jdbc:mysql://localhost:3306/enterprisejavabatch";
		String username="root";
		String password="Root@123";
		
		String sqlSelectQuery ="select * from student";
		String sqlInsertQuery = "insert into student values (45,'Rohit',37,'MI')";
		String sqlUpdateQuery = "update student set sage=34 where sid=18";
		String sqlDeleteQuery ="delete from student where sid=45";
		
		try (Scanner sc = new Scanner(System.in)) {
			while(true) {
				System.out.println("========== DataBase Operations Menu ==========\n"
						+"Enter number as per below list:- \n"
						+"1 Read\n"
						+"2 Create\n"
						+"3 Update\n"
						+"4 Delete\n"
						+"0 Exit\n"
						+"==============================================");
				int number = sc.nextInt();
				
				switch(number) {
				case 1: 
					connection = DriverManager.getConnection(url, username, password);
					if(connection != null) {
						Statement statement = connection.createStatement();
						if(statement != null) {
							ResultSet resultSet = statement.executeQuery(sqlSelectQuery);
							if(resultSet != null) {
								System.out.println("SID\tSNAME\tSAGE\tSADDR");
								while(resultSet.next()){
									Integer id = resultSet.getInt(1);
									String name = resultSet.getString(2);
									Integer age = resultSet.getInt(3);
									String team = resultSet.getString(4);
									System.out.println(id+"\t"+name+"\t"+age+"\t"+team);
								}
								resultSet.close();
							}
							statement.close();
						}
						connection.close();
					}
					enterReturn();
					break;
				case 2: 
					connection = DriverManager.getConnection(url, username, password);
					if(connection != null) {
						Statement statement = connection.createStatement();
						if(statement != null) {
							int arows = statement.executeUpdate(sqlInsertQuery);
							if(arows > 0)
								System.out.println("Number of rows affected:- "+arows);
							else
								System.out.println("Record not able to insert.");
							statement.close();
						}
						connection.close();
					}
					enterReturn();
					break;
				case 3:
					connection = DriverManager.getConnection(url, username, password);
					if(connection != null) {
						Statement statement = connection.createStatement();
						if(statement != null) {
							int arows = statement.executeUpdate(sqlUpdateQuery);
							if(arows>0)
								System.out.println("Number of rows affected:- "+arows);
							else
								System.out.println("Record is not available to update for the given sid.");
							statement.close();
						}
						connection.close();
					}
					enterReturn();
					break;
				case 4:
					connection = DriverManager.getConnection(url, username, password);
					if(connection != null) {
						Statement statement = connection.createStatement();
						if(statement != null) {
							int arows = statement.executeUpdate(sqlDeleteQuery);
							if(arows>0)
								System.out.println("Number of rows affected:- "+arows);
							else
								System.out.println("Sorry, Sid not present to delete from the student table.");
							statement.close();
						}
						connection.close();
					}
					enterReturn();
					break;
				case 0:
					System.out.println("Bye!! See you again.");
					System.exit(0);
				default:System.out.println("Enter number between 1 to 4 only...");
				}
			}
		}catch(InputMismatchException e) {
			System.out.println("Please enter number only.");
		}
	}
}